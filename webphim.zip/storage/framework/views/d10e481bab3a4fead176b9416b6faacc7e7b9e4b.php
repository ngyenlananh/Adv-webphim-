
<?php $__env->startSection('content'); ?>
     <div class="row container" id="wrapper">
               <div class="halim-panel-filter">
                  <div class="panel-heading">
                     <div class="row">
                        <div class="col-xs-6">
                           <div class="yoast_breadcrumb hidden-xs"><span><span><a href=""><?php echo e($category_slug->title); ?></a></div>
                        </div>
                     </div>
                  </div>
                  <div id="ajax-filter" class="panel-collapse collapse" aria-expanded="true" role="menu">
                     <div class="ajax"></div>
                  </div>
               </div>
               <main id="main-contents" class="col-xs-12 col-sm-12 col-md-8">
                  <section>
                     <div class="section-bar clearfix">
                        <h1 class="section-title"><span><?php echo e($category_slug->title); ?></span></h1>
                     </div>
                     <div class="halim_box">
                        <?php $__currentLoopData = $movie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $mov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="col-md-3 col-sm-3 col-xs-6 thumb grid-item post-27021">
                           <div class="halim-item">
                              <a class="halim-thumb" href="<?php echo e(route('phim',[$mov->slug])); ?>" title="<?php echo e($mov->title); ?>">
                                 <figure><img class="lazy img-responsive" src="<?php echo e(asset('uploads/movie/'.$mov->image)); ?>" alt="<?php echo e($mov->title); ?>" title="<?php echo e($mov->title); ?>"></figure>
                                 <?php if($mov->chanle==0): ?>
                                    <?php if($mov->hd_sd==0): ?>
                                       <span class="status">HD</span>
                                       <?php elseif($mov->hd_sd==1): ?>
                                       <span class="status">SD</span>
                                       <?php else: ?>
                                       <span class="status">Cam</span>
                                    <?php endif; ?>
                                 <?php else: ?>
                                     <span class="status">Tập <?php echo e($mov->tap); ?>/<?php echo e($mov->episode); ?></span>
                                 <?php endif; ?>

                                 <?php if($mov->phude==1): ?>
                                   <span class="episode"><i class="fa fa-play" aria-hidden="true"></i>Phụ đề</span> 
                                 <?php else: ?>
                                   <span class="episode"><i class="fa fa-play" aria-hidden="true"></i>Thuyết Minh</span> 
                                 <?php endif; ?>
                                 <div class="icon_overlay"></div>
                                 <div class="halim-post-title-box">
                                    <div class="halim-post-title ">
                                       <p class="entry-title"><?php echo e($mov->title); ?></p>
                                       <p class="original_title"><?php echo e($mov->tentienganh); ?></p>
                                    </div>
                                 </div>
                              </a>
                           </div>
                        </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </div>
                     <div class="clearfix"></div>
                     <div class="text-center">
                        <?php echo e($movie->links('pagination::bootstrap-4')); ?>

                     </div>
                  </section>
               </main>
               <aside id="sidebar" class="col-xs-12 col-sm-12 col-md-4">
               <div id="halim_tab_popular_videos-widget-7" class="widget halim_tab_popular_videos-widget">
                  <div class="section-bar clearfix">
                     <div class="section-title">
                        <span>Phim Hot</span>
                        
                     </div>
                  </div>
                  <section class="tab-content">
                     <div role="tabpanel" class="tab-pane active halim-ajax-popular-post">
                        <div class="halim-ajax-popular-post-loading hidden"></div>
                        <div id="halim-ajax-popular-post" class="popular-post">
                           <?php $__currentLoopData = $movie_noibat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $noibat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="item post-37176">
                              <a href="<?php echo e(route('phim',[$noibat->slug])); ?>" title="<?php echo e($noibat->title); ?>">
                                 <div class="item-link">
                                    <img src="<?php echo e(asset('uploads/movie/'.$noibat->image)); ?>" class="lazy post-thumb" alt="<?php echo e($noibat->title); ?>" title="<?php echo e($noibat->title); ?>" />
                                    <?php if($noibat->chanle==0): ?>
                                    <?php if($noibat->hd_sd==0): ?>
                                       <span class="is_trailer">HD</span>
                                       <?php elseif($noibat->hd_sd==1): ?>
                                       <span class="is_trailer">SD</span>
                                       <?php else: ?>
                                       <span class="is_trailer">Cam</span>
                                    <?php endif; ?>
                                    <?php else: ?>
                                       <span class="is_trailer"><?php echo e($noibat->tap); ?>/<?php echo e($noibat->episode); ?></span>
                                    <?php endif; ?>
                                 </div>
                                 <p class="title"><?php echo e($noibat->title); ?></p>
                              </a>
                              <div class="viewsCount" style="color: #9d9d9d;">3.2K lượt xem</div>
                              <div style="float: left;">
                                 <span class="user-rate-image post-large-rate stars-large-vang" style="display: block;/* width: 100%; */">
                                 <span style="width: 0%"></span>
                                 </span>
                              </div>
                           </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                          
                        </div>
                     </div>
                  </section>
                  <div class="clearfix"></div>
               </div>
            </aside>
            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webphim\resources\views/pages/category.blade.php ENDPATH**/ ?>