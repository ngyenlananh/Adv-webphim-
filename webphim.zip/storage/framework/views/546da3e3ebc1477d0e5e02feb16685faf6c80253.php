
<?php $__env->startSection('content'); ?>
<div class="row container" id="wrapper">
            <div class="halim-panel-filter">
               <div class="panel-heading">
                  <div class="row">
                     <div class="col-xs-6">
                        <div class="yoast_breadcrumb hidden-xs"><span><span><a href="<?php echo e(route('category',[$movie->category->slug])); ?>"><?php echo e($movie->category->title); ?></a> » 
                          <span>
                          <a href="<?php echo e(route('country',[$movie->country->slug])); ?>"><?php echo e($movie->country->title); ?></a> » 
                          <?php $__currentLoopData = $movie->movie_genre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <a href="<?php echo e(route('genre',[$gen->slug])); ?>"><?php echo e($gen->title); ?></a> » 
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <span class="breadcrumb_last" aria-current="page"><?php echo e($movie->title); ?></span>
                        </span>
                        </span></span>
                    </div>
                     </div>
                  </div>
               </div>
               <div id="ajax-filter" class="panel-collapse collapse" aria-expanded="true" role="menu">
                  <div class="ajax"></div>
               </div>
            </div>
            <main id="main-contents" class="col-xs-12 col-sm-12 col-md-8">
               <section id="content" class="test">
                  <div class="clearfix wrap-content">
                    
                     <div class="halim-movie-wrapper">
                        <div class="title-block">
                           <div id="bookmark" class="bookmark-img-animation primary_ribbon" data-id="38424">
                              <div class="halim-pulse-ring"></div>
                           </div>
                           <div class="title-wrapper" style="font-weight: bold;">
                              Bookmark
                           </div>
                        </div>
                        <div class="movie_info col-xs-12">
                           <div class="movie-poster col-md-3">
                              <img class="movie-thumb" src="<?php echo e(asset('uploads/movie/'.$movie->image)); ?>" alt="<?php echo e($movie->title); ?>">
                               
                                  <?php if($movie->resolution!=5): ?>
                                    <?php if($episode_current_list_count>0): ?>
                                    <div class="bwa-content">
                                       <div class="loader"></div>
                                       <a href="<?php echo e(url('xem-phim/'.$movie->slug.'/tap-'.$episode_tapdau->episode)); ?>" class="bwac-btn">
                                       <i class="fa fa-play"></i>
                                       </a>
                                    </div> 
                                    <?php endif; ?>
                                  <?php else: ?>
                                  <a href="#watch_trailer" style="display: block;" class="btn btn-primary watch_trailer">Xem Trailer</a>
                                 
                              <?php endif; ?>
                           
                           </div>
                           <div class="film-poster col-md-9">
                              <h1 class="movie-title title-1" style="display:block;line-height:35px;margin-bottom: -14px;color: #ffed4d;text-transform: uppercase;font-size: 18px;"><?php echo e($movie->title); ?></h1>
                              <h2 class="movie-title title-2" style="font-size: 12px;"><?php echo e($movie->name_eng); ?></h2>
                              <ul class="list-info-group">
                                 <li class="list-info-group-item"><span>Trạng Thái</span> : <span class="quality">
                                      <?php if($movie->resolution==0): ?>
                                              HD
                                          <?php elseif($movie->resolution==1): ?>
                                            SD
                                          <?php elseif($movie->resolution==2): ?>
                                            HDCam
                                          <?php elseif($movie->resolution==3): ?>
                                             Cam
                                          <?php elseif($movie->resolution==4): ?>
                                            FullHD
                                          <?php else: ?> 
                                            Trailer

                                          <?php endif; ?>
                                 </span>
                                 <?php if($movie->resolution!=5): ?>
                                 <span class="episode">
                                     <?php if($movie->phude==0): ?>
                                        Phụ đề
                                      <?php else: ?>
                                        Thuyết minh
                                      <?php endif; ?>
                                 </span>
                                 <?php endif; ?>
                               </li>
                                 
                                 <li class="list-info-group-item"><span>Thời lượng</span> : 
                                  <?php echo e($movie->thoiluong); ?>



                                 </li>
                                 <li class="list-info-group-item"><span>Tập phim</span> : 
                                <?php if($movie->thuocphim=='phimbo'): ?>
                                  <?php echo e($episode_current_list_count); ?>/<?php echo e($movie->sotap); ?> - 
                                  <?php if($episode_current_list_count==$movie->sotap): ?>
                                      Hoàn thành
                                  <?php else: ?>
                                    Đang cập nhập
                                  <?php endif; ?>
                                <?php else: ?>
                                FullHD 
                                HD
                                <?php endif; ?>

                                 </li>

                                 <li class="list-info-group-item"><span>Thể loại</span> : 
                                  <?php $__currentLoopData = $movie->movie_genre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route('genre',$gen->slug)); ?>" rel="category tag"><?php echo e($gen->title); ?></a>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                 </li>
                                 <li class="list-info-group-item"><span>Danh mục</span> : 
                                    <a href="<?php echo e(route('category',$movie->category->slug)); ?>" rel="category tag"><?php echo e($movie->category->title); ?></a>
                                 </li>
                                 <li class="list-info-group-item"><span>Quốc gia</span> : 
                                    <a href="<?php echo e(route('country',$movie->country->slug)); ?>" rel="tag"><?php echo e($movie->country->title); ?></a>
                                 </li>
                                  <li class="list-info-group-item"><span>Tập phim mới nhất</span> : 
                                  <?php if($episode_current_list_count>0): ?>
                                    <?php if($movie->thuocphim=='phimbo'): ?>
                                      
                                          <?php $__currentLoopData = $episode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$ep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <a href="<?php echo e(url('xem-phim/'.$ep->movie->slug.'/tap-'.$ep->episode)); ?>" rel="tag">Tập <?php echo e($ep->episode); ?></a>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     
                                    <?php elseif($movie->thuocphim=='phimle'): ?>
                                      <a href="" rel="tag">HD</a>
                                      <a href="" rel="tag">FullHD</a>

                                   <?php endif; ?>  
                                  <?php else: ?>
                                    Đang cập nhật

                                  <?php endif; ?>
                                 </li>
                                 
                              </ul>
                              <div class="movie-trailer hidden"></div>
                           </div>
                        </div>
                     </div>
                     <div class="clearfix"></div>
                     <div id="halim_trailer"></div>
                     <div class="clearfix"></div>
                     <div class="section-bar clearfix">
                        <h2 class="section-title"><span style="color:#ffed4d">Nội dung phim</span></h2>
                     </div>
                     <div class="entry-content htmlwrap clearfix">
                        <div class="video-item halim-entry-box">
                           <article id="post-38424" class="item-content">
                              <?php echo e($movie->description); ?>

                           </article>
                        </div>
                     </div>
                     <!--Tags phim-->
                    <div class="section-bar clearfix">
                        <h2 class="section-title"><span style="color:#ffed4d">Tags phim</span></h2>
                     </div>
                     <div class="entry-content htmlwrap clearfix">
                        <div class="video-item halim-entry-box">
                           <article id="post-38424" class="item-content">
                            <?php if($movie->tags!=NULL): ?>
                              <?php
                              $tags = array();
                              $tags = explode(',', $movie->tags);

                              ?>
                              <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(url('tag/'.$tag)); ?>"><?php echo e($tag); ?></a>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?> 
                            <?php echo e($movie->title); ?>

                            <?php endif; ?>
                           </article>
                        </div>
                     </div>
                      <!--Comment fb-->
                    <div class="section-bar clearfix">
                        <h2 class="section-title"><span style="color:#ffed4d">Bình luận</span></h2>
                     </div>
                     <div class="entry-content htmlwrap clearfix">
                          <?php
                          $current_url = Request::url(); 
                        
                          ?>
                        <div class="video-item halim-entry-box">
                           <article id="post-38424" class="item-content">
                            <div class="fb-comments" data-href="<?php echo e($current_url); ?>" data-width="100%" data-numposts="10"></div>
                           </article>
                        </div>
                     </div>
                     <?php if($movie->trailer!=NULL): ?>
                      <!--Trailer phim-->
                    <div class="section-bar clearfix">
                        <h2 class="section-title"><span style="color:#ffed4d">Trailer phim</span></h2>

                     </div>
                     <div class="entry-content htmlwrap clearfix">
                        <div class="video-item halim-entry-box">
                         
                           <article id="watch_trailer" class="item-content">

                            <iframe width="100%" height="315" src="https://www.youtube.com/embed/<?php echo e($movie->trailer); ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

                           </article>
                        </div>
                     </div>
                     <?php endif; ?>
                  </div>
               </section>
               <section class="related-movies">
                  <div id="halim_related_movies-2xx" class="wrap-slider">
                     <div class="section-bar clearfix">
                        <h3 class="section-title"><span>CÓ THỂ BẠN MUỐN XEM</span></h3>
                     </div>
                     <div id="halim_related_movies-2" class="owl-carousel owl-theme related-film">
                        <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $hot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="thumb grid-item post-38498">
                           <div class="halim-item">
                              <a class="halim-thumb" href="<?php echo e(route('movie',$hot->slug)); ?>" title="<?php echo e($hot->title); ?>">
                                 <figure><img class="lazy img-responsive" src="<?php echo e(asset('uploads/movie/'.$hot->image)); ?>" alt="<?php echo e($hot->title); ?>" title="Đại Thánh Vô Song"></figure>
                                 <span class="status">
                                    <?php if($hot->resolution==0): ?>
                                             HD
                                         <?php elseif($hot->resolution==1): ?>
                                           SD
                                         <?php elseif($hot->resolution==2): ?>
                                           HDCam
                                         <?php elseif($hot->resolution==3): ?>
                                            Cam
                                         <?php else: ?>
                                           FullHD

                                         <?php endif; ?>

                                 </span><span class="episode"><i class="fa fa-play" aria-hidden="true"></i>
                                     <?php if($hot->phude==0): ?>
                                        Phụ đề
                                      <?php else: ?>
                                        Thuyết minh
                                      <?php endif; ?>
                                 </span> 
                                 <div class="icon_overlay"></div>
                                 <div class="halim-post-title-box">
                                    <div class="halim-post-title ">
                                       <p class="entry-title"><?php echo e($hot->title); ?></p>
                                       <p class="original_title"><?php echo e($hot->name_eng); ?></p>
                                    </div>
                                 </div>
                              </a>
                           </div>
                        </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                     </div>
                     <script>
                        $(document).ready(function($) {				
                        var owl = $('#halim_related_movies-2');
                        owl.owlCarousel({loop: true,margin: 4,autoplay: true,autoplayTimeout: 4000,autoplayHoverPause: true,nav: true,navText: ['<i class="hl-down-open rotate-left"></i>', '<i class="hl-down-open rotate-right"></i>'],responsiveClass: true,responsive: {0: {items:2},480: {items:3}, 600: {items:4},1000: {items: 4}}})});
                     </script>
                  </div>
               </section>
            </main>
            <?php echo $__env->make('pages.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webphim\resources\views/pages/movie.blade.php ENDPATH**/ ?>