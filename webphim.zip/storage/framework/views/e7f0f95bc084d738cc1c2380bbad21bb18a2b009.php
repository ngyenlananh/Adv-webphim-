<?php $__env->startSection('content'); ?>

<div class="row container" id="wrapper">

            <div class="halim-panel-filter">

               <div id="ajax-filter" class="panel-collapse collapse" aria-expanded="true" role="menu">

                  <div class="ajax"></div>

               </div>

            </div>

            <div class="col-xs-12 carausel-sliderWidget">

               <section id="halim-advanced-widget-4">

                  <div class="section-heading">

                     <a href="danhmuc.php" title="Phim Chiếu Rạp">

                     <span class="h-text">Phim Hot</span>

                     </a>

                     <ul class="heading-nav pull-right hidden-xs">

                        <li class="section-btn halim_ajax_get_post" data-catid="4" data-showpost="12" data-widgetid="halim-advanced-widget-4" data-layout="6col"><span data-text="Xem Thêm"></span></li>

                     </ul>

                  </div>

                

                   <div id="halim_related_movies-2" class="owl-carousel owl-theme related-film">

                        <?php $__currentLoopData = $movie_noibat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $relate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <article class="thumb grid-item post-38498">

                           <div class="halim-item">

                              <a class="halim-thumb" href="<?php echo e(route('phim',[$relate->slug])); ?>" title="<?php echo e($relate->title); ?>">

                                 <figure><img class="lazy img-responsive" src="<?php echo e(asset('uploads/movie/'.$relate->image)); ?>" alt="<?php echo e($relate->title); ?>" title="<?php echo e($relate->title); ?>"></figure>

                                 <?php if($relate->chanle==0): ?>

                                    <?php if($relate->hd_sd==0): ?>

                                       <span class="status">HD</span>

                                       <?php elseif($relate->hd_sd==1): ?>

                                       <span class="status">SD</span>

                                       <?php else: ?>

                                       <span class="status">Cam</span>

                                    <?php endif; ?>

                                 <?php else: ?>

                                    <span class="status">Tập <?php echo e($relate->tap); ?>/<?php echo e($relate->episode); ?></span>

                                 <?php endif; ?>



                                 <?php if($relate->phude==1): ?>

                                   <span class="episode"><i class="fa fa-play" aria-hidden="true"></i>Phụ đề</span> 

                                 <?php else: ?>

                                   <span class="episode"><i class="fa fa-play" aria-hidden="true"></i>Thuyết Minh</span> 

                                 <?php endif; ?>

                            

                                 <div class="icon_overlay"></div>

                                 <div class="halim-post-title-box">

                                    <div class="halim-post-title ">

                                       <p class="entry-title"><?php echo e($relate->title); ?></p>

                                       <p class="original_title">Monkey King: The One And Only</p>

                                    </div>

                                 </div>

                              </a>

                           </div>

                        </article>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                     </div>

                     <script>

                        jQuery(document).ready(function($) {            

                        var owl = $('#halim_related_movies-2');

                        owl.owlCarousel({loop: true,margin: 5,autoplay: true,autoplayTimeout: 3000,autoplayHoverPause: true,nav: true,navText: ['<i class="fa fa-play"></i>', '<i class="fa fa-play"></i>'],responsiveClass: true,responsive: {0: {items:2},480: {items:3}, 600: {items:4},1000: {items: 5}}})});

                     </script>

                     

               </section>

               <div class="clearfix"></div>

            </div>

            <main id="main-contents" class="col-xs-12 col-sm-12 col-md-8">

               <?php $__currentLoopData = $category_noibat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate_home): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

               <section id="halim-advanced-widget-2">

                  <div class="section-heading">

                     <a href="danhmuc.php" title="Phim Bộ">

                     <span class="h-text"><?php echo e($cate_home->title); ?></span>

                     </a>

                  </div>

                  <div id="halim-advanced-widget-2-ajax-box" class="halim_box">

                     <?php $__currentLoopData = $cate_home->lastest_film; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lastest_film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                     <article class="col-md-3 col-sm-3 col-xs-6 thumb grid-item post-37606">

                        <div class="halim-item">

                           <a class="halim-thumb" href="<?php echo e(route('phim',[$lastest_film->slug])); ?>">

                              <figure><img class="lazy img-responsive" src="<?php echo e(asset('uploads/movie/'.$lastest_film->image)); ?>" alt="<?php echo e($lastest_film->title); ?>" title="<?php echo e($lastest_film->title); ?>"></figure>

                              <?php if($lastest_film->chanle==0): ?>

                                    <?php if($lastest_film->hd_sd==0): ?>

                                       <span class="status">HD</span>

                                       <?php elseif($lastest_film->hd_sd==1): ?>

                                       <span class="status">SD</span>

                                       <?php else: ?>

                                       <span class="status">Cam</span>

                                    <?php endif; ?>

                                 <?php else: ?>

                                     <span class="status">Tập <?php echo e($lastest_film->tap); ?>/<?php echo e($lastest_film->episode); ?></span>

                                 <?php endif; ?>



                                 <?php if($lastest_film->phude==1): ?>

                                   <span class="episode"><i class="fa fa-play" aria-hidden="true"></i>Phụ đề</span> 

                                 <?php else: ?>

                                   <span class="episode"><i class="fa fa-play" aria-hidden="true"></i>Thuyết Minh</span> 

                                 <?php endif; ?>

                              <div class="icon_overlay"></div>

                              <div class="halim-post-title-box">

                                 <div class="halim-post-title ">

                                    <p class="entry-title"><?php echo e($lastest_film->title); ?></p>

                                    <p class="original_title"><?php echo e($lastest_film->tentienganh); ?></p>

                                 </div>

                              </div>

                           </a>

                        </div>

                     </article>

                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                     

                  </div>

               </section>

               <div class="clearfix"></div>

              

               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </main>

          

         </div>

        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webphim\resources\views/pages/home.blade.php ENDPATH**/ ?>