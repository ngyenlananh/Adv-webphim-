<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="row justify-content-center">

        <div class="col-md-12">

            <div class="card">

                <div class="card-header">Quốc gia phim</div>



                <div class="card-body">

                    <?php if(session('status')): ?>

                        <div class="alert alert-success" role="alert">

                            <?php echo e(session('status')); ?>


                        </div>

                    <?php endif; ?>

                    <?php if(isset($country)): ?>

                    <?php echo Form::open(['route' => ['country.update',$country->id],'method'=>'PUT']); ?>


                    <?php else: ?>

                    <?php echo Form::open(['route' => 'country.store','method'=>'post']); ?>


                    <?php endif; ?>

                      <div class="form-group">

                        <label>Title</label>

                        <?php echo Form::text('title', isset($country) ? $country->title : '' , ['placeholder'=>'Title...', 'class'=>'form-control','id'=>'slug','onkeyup' => 'ChangeToSlug()']); ?>


                      </div>

                      <div class="form-group">

                        <label>Keywords</label>

                        <?php echo Form::text('keywords', isset($country) ? $country->keywords : '' , ['placeholder'=>'Keywords...', 'class'=>'form-control']); ?>


                      </div>

                      <div class="form-group">

                        <label>Slug</label>

                        <?php echo Form::text('slug', isset($country) ? $country->slug : '', ['placeholder'=>'Slug', 'class'=>'form-control','id'=>'convert_slug']); ?>


                      </div>

                      <div class="form-group">

                        <label>Description</label>

                        <?php echo Form::textarea('desc', isset($country) ? $country->description : '', ['placeholder'=>'Desc', 'class'=>'form-control']); ?>


                      </div>



                      <?php if(isset($country)): ?>

                       <?php echo Form::submit('Cập nhật', ['class' => 'btn btn-success']); ?>


                      <?php else: ?>

                       <?php echo Form::submit('Thêm mới', ['class' => 'btn btn-danger']); ?>


                      <?php endif; ?>



                    <?php echo Form::close(); ?>


                    <table class="table table-striped">

                    <thead>

                      <tr>

                        <th scope="col">#</th>

                        <th scope="col">Title</th>

                         <th scope="col">Keywords</th>

                        <th scope="col">Slug</th>

                        <th scope="col">Description</th>

                        <th scope="col">Manage</th>

                      </tr>

                    </thead>

                    <tbody>

                      <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                      <tr>

                        <th scope="row"><?php echo e($key); ?></th>

                        <td><?php echo e($cate->title); ?></td>

                        <td><?php echo e($cate->keywords); ?></td>

                        <td><?php echo e($cate->slug); ?></td>

                        <td><?php echo e($cate->description); ?></td>

                        <td>

                          <?php echo Form::open(['method' => 'DELETE','route' => ['country.destroy', $cate->id],'style'=>'display:inline','onsubmit' => 'return confirm("Xóa?")']); ?>


                          <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>


                          <?php echo Form::close(); ?>




                          <a href="<?php echo e(route('country.edit',[$cate->id])); ?>" class="btn btn-warning">Edit</a>

                        </td>

                      </tr>

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

                  </table>

                </div>



            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gymmuscle/domains/phimchuatv.top/public_html/resources/views/admincp/country/form.blade.php ENDPATH**/ ?>