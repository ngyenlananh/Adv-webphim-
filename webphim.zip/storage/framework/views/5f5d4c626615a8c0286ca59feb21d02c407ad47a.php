
<?php $__env->startSection('content'); ?>
<div class="row container" id="wrapper">
            <div class="halim-panel-filter">
               <div class="panel-heading">
                  <div class="row">
                     <div class="col-xs-6">
                        <div class="yoast_breadcrumb hidden-xs"><span><span><a href="<?php echo e(route('category',[$movie->category->slug])); ?>"><?php echo e($movie->category->title); ?></a> » <span><a href="<?php echo e(route('country',[$movie->country->slug])); ?>"><?php echo e($movie->country->title); ?></a> » <span class="breadcrumb_last" aria-current="page"><?php echo e($movie->title); ?></span></span></span></span></div>
                     </div>
                  </div>
               </div>
               <div id="ajax-filter" class="panel-collapse collapse" aria-expanded="true" role="menu">
                  <div class="ajax"></div>
               </div>
            </div>
            <main id="main-contents" class="col-xs-12 col-sm-12 col-md-8">
               <section id="content" class="test">
                  <div class="clearfix wrap-content">
                    
                     <div class="halim-movie-wrapper">
                        <div class="title-block">
                           <div id="bookmark" class="bookmark-img-animation primary_ribbon" data-id="38424">
                              <div class="halim-pulse-ring"></div>
                           </div>
                           <div class="title-wrapper" style="font-weight: bold;">
                              Bookmark
                           </div>
                        </div>
                        <div class="movie_info col-xs-12">
                           <div class="movie-poster col-md-3">
                              <img class="movie-thumb" src="https://images2-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&gadget=a&no_expand=1&refresh=604800&url=https://1.bp.blogspot.com/-fL7o9nefEPc/YOk_YIB6QRI/AAAAAAAAJn8/hahCLlgRq4AFc8O4YeKhpb5zncixXAF0wCLcBGAsYHQ/s320/images.jpg" alt="GÓA PHỤ ĐEN">
                              <div class="bwa-content">
                                 <div class="loader"></div>
                                 <a href="<?php echo e(route('watch')); ?>" class="bwac-btn">
                                 <i class="fa fa-play"></i>
                                 </a>
                              </div>
                           </div>
                           <div class="film-poster col-md-9">
                              <h1 class="movie-title title-1" style="display:block;line-height:35px;margin-bottom: -14px;color: #ffed4d;text-transform: uppercase;font-size: 18px;"><?php echo e($movie->title); ?></h1>
                              <h2 class="movie-title title-2" style="font-size: 12px;"><?php echo e($movie->name_eng); ?></h2>
                              <ul class="list-info-group">
                                 <li class="list-info-group-item"><span>Trạng Thái</span> : <span class="quality">HD</span><span class="episode">Vietsub</span></li>
                                 
                                 <li class="list-info-group-item"><span>Thời lượng</span> : 133 Phút</li>
                                 <li class="list-info-group-item"><span>Thể loại</span> : 
                                    <a href="<?php echo e(route('genre',$movie->genre->slug)); ?>" rel="category tag"><?php echo e($movie->genre->title); ?></a>
                                 </li>
                                 <li class="list-info-group-item"><span>Danh mục</span> : 
                                    <a href="<?php echo e(route('category',$movie->category->slug)); ?>" rel="category tag"><?php echo e($movie->category->title); ?></a>
                                 </li>
                                 <li class="list-info-group-item"><span>Quốc gia</span> : 
                                    <a href="<?php echo e(route('country',$movie->country->slug)); ?>" rel="tag"><?php echo e($movie->country->title); ?></a>
                                 </li>
                                 
                              </ul>
                              <div class="movie-trailer hidden"></div>
                           </div>
                        </div>
                     </div>
                     <div class="clearfix"></div>
                     <div id="halim_trailer"></div>
                     <div class="clearfix"></div>
                     <div class="section-bar clearfix">
                        <h2 class="section-title"><span style="color:#ffed4d">Nội dung phim</span></h2>
                     </div>
                     <div class="entry-content htmlwrap clearfix">
                        <div class="video-item halim-entry-box">
                           <article id="post-38424" class="item-content">
                              <?php echo e($movie->description); ?>

                           </article>
                        </div>
                     </div>
                  </div>
               </section>
               <section class="related-movies">
                  <div id="halim_related_movies-2xx" class="wrap-slider">
                     <div class="section-bar clearfix">
                        <h3 class="section-title"><span>CÓ THỂ BẠN MUỐN XEM</span></h3>
                     </div>
                     <div id="halim_related_movies-2" class="owl-carousel owl-theme related-film">
                        <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $hot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="thumb grid-item post-38498">
                           <div class="halim-item">
                              <a class="halim-thumb" href="<?php echo e(route('movie',$hot->slug)); ?>" title="<?php echo e($hot->title); ?>">
                                 <figure><img class="lazy img-responsive" src="<?php echo e(asset('uploads/movie/'.$hot->image)); ?>" alt="<?php echo e($hot->title); ?>" title="Đại Thánh Vô Song"></figure>
                                 <span class="status">HD</span><span class="episode"><i class="fa fa-play" aria-hidden="true"></i>Vietsub</span> 
                                 <div class="icon_overlay"></div>
                                 <div class="halim-post-title-box">
                                    <div class="halim-post-title ">
                                       <p class="entry-title"><?php echo e($hot->title); ?></p>
                                       <p class="original_title"><?php echo e($hot->name_eng); ?></p>
                                    </div>
                                 </div>
                              </a>
                           </div>
                        </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                     </div>
                     <script>
                        $(document).ready(function($) {				
                        var owl = $('#halim_related_movies-2');
                        owl.owlCarousel({loop: true,margin: 4,autoplay: true,autoplayTimeout: 4000,autoplayHoverPause: true,nav: true,navText: ['<i class="hl-down-open rotate-left"></i>', '<i class="hl-down-open rotate-right"></i>'],responsiveClass: true,responsive: {0: {items:2},480: {items:3}, 600: {items:4},1000: {items: 4}}})});
                     </script>
                  </div>
               </section>
            </main>
            <aside id="sidebar" class="col-xs-12 col-sm-12 col-md-4"></aside>
         </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\webphim\resources\views/pages/movie.blade.php ENDPATH**/ ?>