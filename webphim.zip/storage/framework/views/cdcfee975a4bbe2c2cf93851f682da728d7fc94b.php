
<?php $__env->startSection('content'); ?>
 <div class="row container" id="wrapper">
            <div class="halim-panel-filter">
               <div class="panel-heading">
                  <div class="row">
                     <div class="col-xs-6">
                        <div class="yoast_breadcrumb hidden-xs">
                           Phimchuatv.com »
                         
                           »
                         
                           <span><a href="<?php echo e(route('xemdanhmuc',[$movie->category->slug])); ?>"><?php echo e($movie->category->title); ?></a> 
                         
                           » <span><a href="<?php echo e(route('xemquocgia',[$movie->country->slug])); ?>"><?php echo e($movie->country->title); ?></a> » <span class="breadcrumb_last" aria-current="page"><?php echo e($movie->title); ?></span></span></span></span></div>
                     </div>
                  </div>
               </div>
               <div id="ajax-filter" class="panel-collapse collapse" aria-expanded="true" role="menu">
                  <div class="ajax"></div>
               </div>
            </div>
            <main id="main-contents" class="col-xs-12 col-sm-12 col-md-8">
               <section id="content" class="test">
                  <div class="clearfix wrap-content">
                    
                     <div class="halim-movie-wrapper">
                        <div class="title-block">
                           <div id="bookmark" class="bookmark-img-animation primary_ribbon" data-id="38424">
                              <div class="halim-pulse-ring"></div>
                           </div>
                           <div class="title-wrapper" style="font-weight: bold;">
                              Bookmark
                           </div>
                        </div>
                        <div class="movie_info col-xs-12">
                           <div class="movie-poster col-md-3">
                              <img class="movie-thumb" src="<?php echo e(asset('public/uploads/movie/'.$movie->image)); ?>" alt="<?php echo e($movie->title); ?>" title="<?php echo e($movie->title); ?>">
                              <div class="bwa-content">
                                 <div class="loader"></div>
                                 <a href="<?php echo e(route('xemphim',[$movie->slug])); ?>" class="bwac-btn">
                                 <i class="fa fa-play"></i>
                                 </a>
                              </div>
                           </div>
                           <div class="film-poster col-md-9">
                              <h1 class="movie-title title-1" style="display:block;line-height:35px;margin-bottom: -14px;color: #ffed4d;text-transform: uppercase;font-size: 18px;"><?php echo e($movie->title); ?></h1>
                              <h2 class="movie-title title-2" style="font-size: 12px;">Black Widow (2021)</h2>
                              <ul class="list-info-group">
                                 <li class="list-info-group-item"><span>Trạng Thái</span> :
                                     <?php if($movie->chanle==0): ?>
                                       <?php if($movie->hd_sd==0): ?>
                                          <span class="quality">HD</span>
                                          <?php elseif($movie->hd_sd==1): ?>
                                          <span class="quality">SD</span>
                                          <?php else: ?>
                                          <span class="quality">Cam</span>
                                       <?php endif; ?>
                                    <?php else: ?>
                                       <span class="status">Tập <?php echo e($movie->tap); ?>/<?php echo e($movie->episode); ?></span>
                                    <?php endif; ?>

                                    <?php if($movie->phude==1): ?>
                                      <span class="episode"><i class="fa fa-play" aria-hidden="true"></i>Phụ đề</span> 
                                    <?php else: ?>
                                      <span class="episode"><i class="fa fa-play" aria-hidden="true"></i>Thuyết Minh</span> 
                                    <?php endif; ?>
                            
                                 
                                 <li class="list-info-group-item"><span>Thời lượng</span> : <?php echo e($movie->thoiluong); ?></li>
                                 <li class="list-info-group-item"><span>Thể loại</span> : 
                                  
                                 <li class="list-info-group-item"><span>Quốc gia</span> : <a href="<?php echo e(route('xemquocgia',[$movie->country->slug])); ?>" rel="tag"><?php echo e($movie->country->title); ?></a></li>
                                
                              </ul>
                              <div class="movie-trailer hidden"></div>
                           </div>
                        </div>
                     </div>
                     <div class="clearfix"></div>
                     <div id="halim_trailer"></div>
                     <div class="clearfix"></div>
                     <div class="section-bar clearfix">
                        <h2 class="section-title"><span style="color:#ffed4d">Nội dung phim</span></h2>
                     </div>
                     <div class="entry-content htmlwrap clearfix">
                        <div class="video-item halim-entry-box">
                           <article id="post-38424" class="item-content">
                              <?php echo e($movie->description); ?>


                           </article>
                           <iframe width="100%" height="315" src="https://www.youtube.com/embed/<?php echo e($movie->trailer); ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                     </div>
                  </div>
               </section>
               <section class="related-movies">
                  <div id="halim_related_movies-2xx" class="wrap-slider">
                     <div class="section-bar clearfix">
                        <h3 class="section-title"><span>CÓ THỂ BẠN MUỐN XEM</span></h3>
                     </div>
                     <div id="halim_related_movies-2" class="owl-carousel owl-theme related-film">
                        <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $relate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="thumb grid-item post-38498">
                           <div class="halim-item">
                              <a class="halim-thumb" href="<?php echo e(route('phim',[$relate->slug])); ?>" title="<?php echo e($relate->title); ?>">
                                 <figure><img class="lazy img-responsive" src="<?php echo e(asset('public/uploads/movie/'.$relate->image)); ?>" alt="<?php echo e($relate->title); ?>" title="<?php echo e($relate->title); ?>"></figure>
                                 <?php if($relate->chanle==0): ?>
                                    <?php if($relate->hd_sd==0): ?>
                                       <span class="status">HD</span>
                                       <?php elseif($relate->hd_sd==1): ?>
                                       <span class="status">SD</span>
                                       <?php else: ?>
                                       <span class="status">Cam</span>
                                    <?php endif; ?>
                                 <?php else: ?>
                                    <span class="status">12/12</span>
                                 <?php endif; ?>

                                 <?php if($relate->phude==1): ?>
                                   <span class="episode"><i class="fa fa-play" aria-hidden="true"></i>Phụ đề</span> 
                                 <?php else: ?>
                                   <span class="episode"><i class="fa fa-play" aria-hidden="true"></i>Thuyết Minh</span> 
                                 <?php endif; ?>
                            
                                 <div class="icon_overlay"></div>
                                 <div class="halim-post-title-box">
                                    <div class="halim-post-title ">
                                       <p class="entry-title"><?php echo e($relate->title); ?></p>
                                       <p class="original_title">Monkey King: The One And Only</p>
                                    </div>
                                 </div>
                              </a>
                           </div>
                        </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </div>
                     <script>
                        jQuery(document).ready(function($) {				
                        var owl = $('#halim_related_movies-2');
                        owl.owlCarousel({loop: false,margin: 4,autoplay: true,autoplayTimeout: 3000,autoplayHoverPause: true,nav: true,navText: ['<i class="hl-down-open rotate-left"></i>', '<i class="hl-down-open rotate-right"></i>'],responsiveClass: true,responsive: {0: {items:2},480: {items:3}, 600: {items:4},1000: {items: 4}}})});
                     </script>
                  </div>
               </section>
            </main>
            <aside id="sidebar" class="col-xs-12 col-sm-12 col-md-4">
               <div id="halim_tab_popular_videos-widget-7" class="widget halim_tab_popular_videos-widget">
                  <div class="section-bar clearfix">
                     <div class="section-title">
                        <span>Phim Hot</span>
                        
                     </div>
                  </div>
                  <section class="tab-content">
                     <div role="tabpanel" class="tab-pane active halim-ajax-popular-post">
                        <div class="halim-ajax-popular-post-loading hidden"></div>
                        <div id="halim-ajax-popular-post" class="popular-post">
                           <?php $__currentLoopData = $movie_noibat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $noibat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="item post-37176">
                              <a href="<?php echo e(route('phim',[$noibat->slug])); ?>" title="<?php echo e($noibat->title); ?>">
                                 <div class="item-link">
                                    <img src="<?php echo e(asset('public/uploads/movie/'.$noibat->image)); ?>" class="lazy post-thumb" alt="<?php echo e($noibat->title); ?>" title="<?php echo e($noibat->title); ?>" />
                                    
                                 </div>
                                 <p class="title"><?php echo e($noibat->title); ?></p>
                              </a>
                              <div class="viewsCount" style="color: #9d9d9d;">3.2K lượt xem</div>
                              <div style="float: left;">
                                 <span class="user-rate-image post-large-rate stars-large-vang" style="display: block;/* width: 100%; */">
                                 <span style="width: 0%"></span>
                                 </span>
                              </div>
                           </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                          
                        </div>
                     </div>
                  </section>
                  <div class="clearfix"></div>
               </div>
            </aside>
         </div>
        

         <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webphim\resources\views/pages/movie.blade.php ENDPATH**/ ?>