

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <a href="<?php echo e(route('movie.create')); ?>" class="btn btn-primary">Thêm Phim</a>
            <table class="table" id="tablephim">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Tên phim</th>
                  <th scope="col">Tags</th>
                  <th scope="col">Thời lượng phim</th>
                  <th scope="col">Hình ảnh</th>
                  <th scope="col">Phim hot</th>
                  <th scope="col">Định dạng</th>
                  <th scope="col">Phụ đề</th>
                  <!-- <th scope="col">Mô tả</th> -->
                  <th scope="col">Đường dẫn</th>
                  <th scope="col">Trạng thái</th>
                  <th scope="col">Danh mục</th>
                  <th scope="col">Thuộc phim</th>
                  <th scope="col">Thể loại</th>
                  <th scope="col">Quốc gia</th>
                  <th scope="col">Số tập</th>
                  <th scope="col">Ngày tạo</th>
                  <th scope="col">Ngày cập nhật</th>
                  <th scope="col">Năm phim</th>
                  <th scope="col">Top views</th>
                  <th scope="col">Quản lý</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <th scope="row"><?php echo e($key); ?></th>
                  <td><?php echo e($cate->title); ?></td>
                  <td><?php echo e($cate->tags); ?></td>
                  <td><?php echo e($cate->thoiluong); ?></td>
                  <td><img width="100" src="<?php echo e(asset('uploads/movie/'.$cate->image)); ?>"></td>
                  <td>
                    <?php if($cate->phim_hot==0): ?>
                        Không
                    <?php else: ?>
                        Có
                    <?php endif; ?>
                  </td>
                  <td>
                    <?php if($cate->resolution==0): ?>
                        HD
                    <?php elseif($cate->resolution==1): ?>
                      SD
                    <?php elseif($cate->resolution==2): ?>
                      HDCam
                    <?php elseif($cate->resolution==3): ?>
                       Cam
                    <?php elseif($cate->resolution==4): ?>
                      FullHD
                    <?php else: ?> 
                      Trailer

                    <?php endif; ?>
                  </td>
                  <td>
                    <?php if($cate->phude==0): ?>
                      Phụ đề
                    <?php else: ?>
                      Thuyết minh
                    <?php endif; ?>
                  </td>
                
                  <!-- <td><?php echo e($cate->description); ?></td> -->
                  <td><?php echo e($cate->slug); ?></td>
                  <td>
                    <?php if($cate->status): ?>
                        Hiển thị
                    <?php else: ?>
                        Không hiển thị
                    <?php endif; ?>
                  </td>
                  <td><?php echo e($cate->category->title); ?></td>
                  <td>
                    <?php if($cate->thuocphim=='phimle'): ?>
                    Phim lẻ
                    <?php else: ?>
                    Phim bộ
                    <?php endif; ?>
                  </td>
                  <td>
                    <?php $__currentLoopData = $cate->movie_genre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="badge badge-dark"><?php echo e($gen->title); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </td>
                  

                  
                  <td><?php echo e($cate->country->title); ?></td>

                  <td><?php echo e($cate->sotap); ?></td>
                  <td><?php echo e($cate->ngaytao); ?></td>
                  <td><?php echo e($cate->ngaycapnhat); ?></td>
                  <td>
                    <?php echo Form::selectYear('year',2000,2022, isset($cate->year) ? $cate->year : '' ,['class'=>'select-year','id'=>$cate->id]); ?>

                  </td>
                  <td>
                     <?php echo Form::select('topview', ['0'=>'Ngày','1'=>'Tuần','2'=>'Tháng'], isset($cate->topview) ? $cate->topview : '', ['class'=>'select-topview','id'=>$cate->id]); ?>

                  </td>
                  <td>
                      <?php echo Form::open(['method'=>'DELETE','route'=>['movie.destroy',$cate->id],'onsubmit'=>'return confirm("Bạn có chắc muốn xóa?")']); ?>

                        <?php echo Form::submit('Xóa', ['class'=>'btn btn-danger']); ?>

                      <?php echo Form::close(); ?>

                      <a href="<?php echo e(route('movie.edit',$cate->id)); ?>" class="btn btn-warning">Sửa</a>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webphim\resources\views/admincp/movie/index.blade.php ENDPATH**/ ?>