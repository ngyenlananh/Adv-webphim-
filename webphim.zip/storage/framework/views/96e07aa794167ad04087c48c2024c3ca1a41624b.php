

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Phim</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(isset($movie)): ?>
                    <?php echo Form::open(['route' => ['movie.update',$movie->id],'method'=>'PUT','enctype'=>'multipart/form-data']); ?>

                    <?php else: ?>
                    <?php echo Form::open(['route' => 'movie.store','method'=>'POST','enctype'=>'multipart/form-data']); ?>

                    <?php endif; ?>
                      <div class="form-group">
                        <?php echo Form::label('Title', 'Title'); ?>

                        <?php echo Form::text('title', isset($movie) ? $movie->title : '' , ['placeholder'=>'Title...', 'class'=>'form-control','id'=>'slug','onkeyup'=>'ChangeToSlug()']); ?>

                      </div>
                      <div class="form-group">
                        <label>Slug</label>
                        <?php echo Form::text('slug', isset($movie) ? $movie->slug : '', ['placeholder'=>'Slug', 'class'=>'form-control','id'=>'convert_slug']); ?>

                      </div>
                      <div class="form-group">
                        <label>Keywords</label>
                        <?php echo Form::text('keywords', isset($movie) ? $movie->keywords : '' , ['placeholder'=>'Keywords...', 'class'=>'form-control']); ?>

                      </div>
                       <div class="form-group">
                        <?php echo Form::label('Episode', 'Episode'); ?>

                        <?php echo Form::text('episode', isset($movie) ? $movie->episode : '' , ['placeholder'=>'Episode...', 'class'=>'form-control']); ?>

                      </div>
                      <div class="form-group">
                        <?php echo Form::label('English Name', 'English Name'); ?>

                        <?php echo Form::text('tentienganh', isset($movie) ? $movie->tentienganh : '' , ['placeholder'=>'English Name...', 'class'=>'form-control']); ?>

                      </div>
                      <div class="form-group">
                        <?php echo Form::label('Trailer', 'Trailer'); ?>

                        <?php echo Form::text('trailer', isset($movie) ? 'https://youtu.be/'.$movie->trailer : '' , ['placeholder'=>'Trailer...', 'class'=>'form-control']); ?>

                      </div>
                      <div class="form-group">
                        <?php echo Form::label('Thời lượng', 'Thời lượng'); ?>

                        <?php echo Form::text('thoiluong', isset($movie) ? $movie->thoiluong : '' , ['placeholder'=>'Thời lượng...', 'class'=>'form-control']); ?>

                      </div>
                      <div class="form-group">
                        <label>Description</label>
                        <?php echo Form::textarea('desc', isset($movie) ? $movie->description : '', ['placeholder'=>'Desc', 'class'=>'form-control']); ?>

                      </div>
                      <div class="form-group">
                        <label>Image</label>
                        <?php echo Form::file('image', ['placeholder'=>'Image', 'class'=>'form-control-file']); ?>

                        <?php if(isset($movie)): ?>
                          <img src="<?php echo e(asset('public/uploads/movie/'.$movie->image)); ?>" width="200px">
                        <?php endif; ?>
                      </div>
                      <div class="form-group">
                        <label>Category</label>
                        
                        <?php echo Form::select('category_id', $categories, isset($movie) ? $movie->category_id : null,['class'=>'form-control','placeholder' => 'Category...']); ?>


                      </div>
                      <div class="form-group">
                        <label>Lẻ/Bộ</label>
                        
                        <?php echo Form::select('chanle', ['1'=>'Phim Bộ','0'=>'Phim Lẻ'], isset($movie) ? $movie->chanle : null ,['class'=>'form-control','placeholder' => 'Bộ/Lẻ...']); ?>


                      </div>
                      <div class="form-group">
                        <label>Phim Hot</label>
                        
                        <?php echo Form::select('phim_hot', ['0'=>'Không','1'=>'Có'], isset($movie) ? $movie->phim_hot : null ,['class'=>'form-control','placeholder' => 'Phim Hot...']); ?>


                      </div>
                       <div class="form-group">
                        <label>Phụ đề/Thuyết minh</label>
                        
                        <?php echo Form::select('phude', ['1'=>'Phụ đề','2'=>'Thuyết minh'], isset($movie) ? $movie->phude : null ,['class'=>'form-control','placeholder' => 'Phụ đề/Thuyết minh...']); ?>


                      </div>
                      <div class="form-group">
                        <label>Hd/Sd/Cam</label>
                        
                        <?php echo Form::select('hd_sd', ['1'=>'Bản Sd','0'=>'Bản Hd','2'=>'Bản Cam'], isset($movie) ? $movie->hd_sd : null ,['class'=>'form-control','placeholder' => 'Hd/Sd...']); ?>


                      </div>
                      <div class="form-group">
                        <label>Country</label>
                        
                        <?php echo Form::select('country_id', $country, isset($movie) ? $movie->country_id : null,['class'=>'form-control','placeholder' => 'Country...']); ?>


                      </div>
                      <div class="form-group">
                        <?php echo Form::label('Genre', 'Genre'); ?><br>
                        <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo Form::checkbox('genre_id[]', $gen->id, isset($film_genre) && $film_genre->contains($gen->id) ? true : false,["class" => "form-group"]); ?>

                        <?php echo Form::label($gen->title, $gen->title, []); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                      <?php if(isset($movie)): ?>
                       <?php echo Form::submit('Cập nhật', ['class' => 'btn btn-success']); ?>

                      <?php else: ?>
                       <?php echo Form::submit('Thêm mới', ['class' => 'btn btn-danger']); ?>

                      <?php endif; ?>

                    <?php echo Form::close(); ?>

                  <table class="table table-striped">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Title</th>
                        <th scope="col">Keywords</th>
                        <th scope="col">Time</th>
                        <th scope="col">Slug</th>
                        <th scope="col">Episode</th>
                        <th scope="col">Description</th>
                        <th scope="col">Image</th>
                        <th scope="col">Category</th>
                        <th scope="col">Genre</th>
                        <th scope="col">Country</th>
                        <th scope="col">Bo/Le</th>
                        <th scope="col">Phụ đề/Thuyết Minh</th>
                        <th scope="col">Hd/Sd/Cam</th>
                        <th scope="col">Hot</th>
                        <th scope="col">Manage</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $movi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"><?php echo e($key); ?></th>
                        <td><?php echo e($movi->title); ?></td>
                        <td><?php echo e($movi->keywords); ?></td>
                        <td><?php echo e($movi->thoiluong); ?></td>
                        <td><?php echo e($movi->slug); ?></td>
                        <td><?php echo e($movi->episode); ?></td>
                        <td><?php echo e($movi->description); ?></td>
                        <td><img src="<?php echo e(asset('public/uploads/movie/'.$movi->image)); ?>" width="100px"></td>
                      
                        <td><?php echo e($movi->category->title); ?></td>
                        <td>
                        <?php $__currentLoopData = $movi->film_genre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php echo e($gen->title); ?>,
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td><?php echo e($movi->country->title); ?></td>
                        <td>
                          <?php if($movi->chanle==0): ?>
                            Lẻ
                          <?php else: ?>
                            Bộ
                          <?php endif; ?>
                        </td>
                         <td>
                          <?php if($movi->phude==1): ?>
                            Phụ đề
                          <?php else: ?>
                            Thuyết minh
                          <?php endif; ?>
                        </td>
                         <td>
                          <?php if($movi->hd_sd==0): ?>
                            HD
                          <?php elseif($movi->hd_sd==1): ?>
                            SD
                          <?php else: ?>
                            Cam
                          <?php endif; ?>
                        </td>
                         <td>
                          <?php if($movi->phim_hot==1): ?>
                            Có
                          <?php else: ?>
                            Không
                          <?php endif; ?>
                        </td>
                        <td>
                          <?php echo Form::open(['method' => 'DELETE','route' => ['movie.destroy', $movi->id],'style'=>'display:inline','onsubmit' => 'return confirm("Xóa?")']); ?>

                          <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                          <?php echo Form::close(); ?>


                          <a href="<?php echo e(route('movie.edit',[$movi->id])); ?>" class="btn btn-warning">Edit</a>
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\webphim\resources\views/admincp/movie/form.blade.php ENDPATH**/ ?>