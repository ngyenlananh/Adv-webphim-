

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
              <a href="<?php echo e(route('movie.index')); ?>" class="btn btn-primary">Liệt Kê Danh Sách Phim</a>
                <div class="card-header">Quản Lý Phim</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(!isset($movie)): ?>
                        <?php echo Form::open(['route'=>'movie.store','method'=>'POST','enctype'=>'multipart/form-data']); ?>

                    <?php else: ?>
                        <?php echo Form::open(['route'=>['movie.update',$movie->id],'method'=>'PUT','enctype'=>'multipart/form-data']); ?>

                    <?php endif; ?>
                        <div class="form-group">
                            <?php echo Form::label('title', 'Tên phim', []); ?>

                            <?php echo Form::text('title', isset($movie) ? $movie->title : '', ['class'=>'form-control','placeholder'=>'...','id'=>'slug','onkeyup'=>'ChangeToSlug()']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('sotap', 'Số tập phim', []); ?>

                            <?php echo Form::text('sotap', isset($movie) ? $movie->sotap : '', ['class'=>'form-control','placeholder'=>'...']); ?>

                        </div>

                        <div class="form-group">
                            <?php echo Form::label('thoiluong', 'Thời lượng phim', []); ?>

                            <?php echo Form::text('thoiluong', isset($movie) ? $movie->thoiluong : '', ['class'=>'form-control','placeholder'=>'...']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('tên tiếng anh', 'Tên tiếng anh', []); ?>

                            <?php echo Form::text('name_eng', isset($movie) ? $movie->name_eng : '', ['class'=>'form-control','placeholder'=>'...']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('trailer', 'Trailer', []); ?>

                            <?php echo Form::text('trailer', isset($movie) ? $movie->trailer : '', ['class'=>'form-control','placeholder'=>'...']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('slug', 'Đường dẫn', []); ?>

                            <?php echo Form::text('slug', isset($movie) ? $movie->slug : '', ['class'=>'form-control','placeholder'=>'...','id'=>'convert_slug']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('description', 'Mô tả phim', []); ?>

                            <?php echo Form::textarea('description', isset($movie) ? $movie->description : '', ['style'=>'resize:none', 'class'=>'form-control','placeholder'=>'...','id'=>'description']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('tags', 'Tags phim', []); ?>

                            <?php echo Form::textarea('tags', isset($movie) ? $movie->tags : '', ['style'=>'resize:none', 'class'=>'form-control','placeholder'=>'...']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('status', 'Trạng thái', []); ?>

                            <?php echo Form::select('status', ['1'=>'Hiển thị','0'=>'Không hiển thị'], isset($movie) ? $movie->status : '', ['class'=>'form-control']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('resolution', 'Định dạng', []); ?>

                            <?php echo Form::select('resolution', ['0'=>'HD','1'=>'SD','2'=>'HDCam','3'=>'Cam','4'=>'FullHD','5'=>'Trailer'], isset($movie) ? $movie->resolution : '', ['class'=>'form-control']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('phude', 'Phụ đề', []); ?>

                            <?php echo Form::select('phude', ['0'=>'Phụ đề','1'=>'Thuyết minh'], isset($movie) ? $movie->phude : '', ['class'=>'form-control']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('Category', 'Danh mục', []); ?>

                            <?php echo Form::select('category_id', $category, isset($movie) ? $movie->category_id : '', ['class'=>'form-control']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('thuocphim', 'Thuộc phim', []); ?>

                            <?php echo Form::select('thuocphim', ['phimle'=>'Phim lẻ','phimbo'=>'Phim bộ'], isset($movie) ? $movie->thuocphim : '', ['class'=>'form-control']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('Country', 'Quốc gia', []); ?>

                            <?php echo Form::select('country_id', $country, isset($movie) ? $movie->country_id : '', ['class'=>'form-control']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('Genre', 'Thể loại', []); ?><br>
                            
                            <?php $__currentLoopData = $list_genre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $gen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(isset($movie)): ?>
                            <?php echo Form::checkbox('genre[]',$gen->id, isset($movie_genre) && $movie_genre->contains($gen->id) ? true : false); ?>

                                <?php else: ?>
                            <?php echo Form::checkbox('genre[]',$gen->id, ''); ?>    
                                <?php endif; ?>
                            <?php echo Form::label('genre', $gen->title); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('Hot', 'Phim hot', []); ?>

                            <?php echo Form::select('phim_hot', ['1'=>'Có','0'=>'Không'], isset($movie) ? $movie->phim_hot : '', ['class'=>'form-control']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('Image', 'Hình ảnh', []); ?>

                            <?php echo Form::file('image', ['class'=>'form-control-file']); ?>

                            <?php if(isset($movie)): ?>
                              <img width="150" src="<?php echo e(asset('uploads/movie/'.$movie->image)); ?>">
                            <?php endif; ?>
                        </div>
                        <?php if(!isset($movie)): ?>
                            <?php echo Form::submit('Thêm Phim', ['class'=>'btn btn-success']); ?>

                        <?php else: ?>
                            <?php echo Form::submit('Cập Nhật Phim', ['class'=>'btn btn-success']); ?>

                        <?php endif; ?>
                    <?php echo Form::close(); ?>

                </div>
            </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webphim\resources\views/admincp/movie/form.blade.php ENDPATH**/ ?>