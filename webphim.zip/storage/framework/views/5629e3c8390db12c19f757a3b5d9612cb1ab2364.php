

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Tập phim</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(isset($episode)): ?>
                    <?php echo Form::open(['route' => ['episode.update',$episode->id],'method'=>'PUT']); ?>

                    <?php else: ?>
                    <?php echo Form::open(['route' => 'episode.store','method'=>'post']); ?>

                    <?php endif; ?>

                      <div class="form-group">
                        <label>Film</label>
                        
                        <?php echo Form::select('film_id', $film, isset($episode) ? $episode->film_id : null,['class'=>'form-control','placeholder' => 'Film...']); ?>


                      </div>
                      <div class="form-group">
                        <label>Episode</label>
                        
                        <?php echo Form::text('episode', isset($episode) ? $episode->episode : '', ['class'=>'form-control','placeholder' => 'Episode...']); ?>


                      </div>
                      <div class="form-group">
                        <label>Link</label>
                        
                        <?php echo Form::textarea('link', isset($episode) ? $episode->link : '', ['class'=>'form-control','placeholder' => 'Link...']); ?>


                      </div>

                      <?php if(isset($episode)): ?>
                       <?php echo Form::submit('Cập nhật', ['class' => 'btn btn-success']); ?>

                      <?php else: ?>
                       <?php echo Form::submit('Thêm mới', ['class' => 'btn btn-danger']); ?>

                      <?php endif; ?>

                    <?php echo Form::close(); ?>

                    <table class="table table-striped">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Film</th>
                        <th scope="col">Episode</th>
                        <th scope="col">Link</th>
                        <th scope="col">Manage</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                      <tr>
                        <th scope="row"><?php echo e($key); ?></th>
                        <td><?php echo e($film->film->title); ?></td>
                        <td><?php echo e($film->episode); ?></td>
                        <td><?php echo e($film->link); ?></td>
                        <td>
                          <?php echo Form::open(['method' => 'DELETE','route' => ['episode.destroy', $film->id],'style'=>'display:inline','onsubmit' => 'return confirm("Xóa?")']); ?>

                          <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                          <?php echo Form::close(); ?>


                          <a href="<?php echo e(route('episode.edit',[$film->id])); ?>" class="btn btn-warning">Edit</a>
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webphim\resources\views/admincp/episode/form.blade.php ENDPATH**/ ?>