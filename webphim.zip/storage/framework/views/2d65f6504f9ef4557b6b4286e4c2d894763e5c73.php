 
<?php $__env->startSection('content'); ?>
  <div class="row container" id="wrapper">
         <div class="halim-panel-filter">
            <div class="panel-heading">
               <div class="row">
                 <div class="col-xs-6">
                  <div class="yoast_breadcrumb hidden-xs">
                           Phimchuatv.com »
                           <?php $__currentLoopData = $movie->film_genre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <a href="<?php echo e(route('xemtheloai',[$gn->slug])); ?>"><?php echo e($gn->title); ?></a> /
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           »
                         
                           <span><a href="<?php echo e(route('xemdanhmuc',[$movie->category->slug])); ?>"><?php echo e($movie->category->title); ?></a> 
                         
                           » <span><a href="<?php echo e(route('xemquocgia',[$movie->country->slug])); ?>"><?php echo e($movie->country->title); ?></a> » <span class="breadcrumb_last" aria-current="page"><?php echo e($movie->title); ?></span></span></span></span></div>
                  </div>
               </div>
            </div>
            <div id="ajax-filter" class="panel-collapse collapse" aria-expanded="true" role="menu">
               <div class="ajax"></div>
            </div>
         </div>
         <main id="main-contents" class="col-xs-12 col-sm-12 col-md-8">
            <section id="content" class="test">
               <div class="clearfix wrap-content">
                  <?php echo $watch->link; ?>

                  <div class="button-watch">
                     <ul class="halim-social-plugin col-xs-4 hidden-xs">
                        <li class="fb-like" data-href="" data-layout="button_count" data-action="like" data-size="small" data-show-faces="true" data-share="true"></li>
                     </ul>
                     <ul class="col-xs-12 col-md-8">
                        <div id="autonext" class="btn-cs autonext">
                           <i class="icon-autonext-sm"></i>
                           <span><i class="hl-next"></i> Autonext: <span id="autonext-status">On</span></span>
                        </div>
                        <div id="explayer" class="hidden-xs"><i class="hl-resize-full"></i>
                           Expand 
                        </div>
                        <div id="toggle-light"><i class="hl-adjust"></i>
                           Light Off 
                        </div>
                        <div id="report" class="halim-switch"><i class="hl-attention"></i> Report</div>
                        <div class="luotxem"><i class="hl-eye"></i>
                           <span>1K</span> lượt xem 
                        </div>
                        <div class="luotxem">
                           <a class="visible-xs-inline" data-toggle="collapse" href="#moretool" aria-expanded="false" aria-controls="moretool"><i class="hl-forward"></i> Share</a>
                        </div>
                     </ul>
                  </div>
                  <div class="collapse" id="moretool">
                     <ul class="nav nav-pills x-nav-justified">
                        <li class="fb-like" data-href="" data-layout="button_count" data-action="like" data-size="small" data-show-faces="true" data-share="true"></li>
                        <div class="fb-save" data-uri="" data-size="small"></div>
                     </ul>
                  </div>
                  <div class="clearfix"></div>
                  <div class="clearfix"></div>
                  <div class="title-block">
                     <a href="javascript:;" data-toggle="tooltip" title="Add to bookmark">
                        <div id="bookmark" class="bookmark-img-animation primary_ribbon" data-id="37976">
                           <div class="halim-pulse-ring"></div>
                        </div>
                     </a>
                     <div class="title-wrapper-xem full">
                        <h1 class="entry-title"><a href="" title="Tôi Và Chúng Ta Ở Bên Nhau" class="tl"><?php echo e($movie->title); ?> tập <?php echo e($watch->episode); ?></a></h1>
                     </div>
                  </div>
                  <div class="entry-content htmlwrap clearfix collapse" id="expand-post-content">
                     <article id="post-37976" class="item-content post-37976"></article>
                  </div>
                  <div class="clearfix"></div>
                  <div class="text-center">
                     <div id="halim-ajax-list-server"></div>
                  </div>
                  <div id="halim-list-server">
                     <ul class="nav nav-tabs" role="tablist">
                        <li role="presentation" class="active server-1"><a href="#server-0" aria-controls="server-0" role="tab" data-toggle="tab"><i class="hl-server"></i> Vietsub</a></li>
                     </ul>
                     <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active server-1" id="server-0">
                           <div class="halim-server">
                              <ul class="halim-list-eps">
                                 <?php $__currentLoopData = $episode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <a href="<?php echo e(route('episode',[$movie->slug,'tap-'.$ep->episode])); ?>"><li class="halim-episode"><span class="halim-btn <?php echo e($ep->episode==$watch->episode ? 'active' : ''); ?> halim-btn-2 halim-info-1-1 box-shadow" data-post-id="37976" data-server="1" data-episode="1" data-position="first" data-embed="0" data-title="<?php echo e($movie->title); ?> tập <?php echo e($watch->episode); ?> - Be Together - vietsub + Thuyết Minh" data-h1="<?php echo e($movie->title); ?> tập <?php echo e($watch->episode); ?>"><?php echo e($ep->episode); ?></span></li></a>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                              <div class="clearfix"></div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="clearfix"></div>
                  <div class="htmlwrap clearfix">
                     <div id="lightout"></div>
                  </div>
            </section>
            <section class="related-movies">
                  <div id="halim_related_movies-2xx" class="wrap-slider">
                     <div class="section-bar clearfix">
                        <h3 class="section-title"><span>CÓ THỂ BẠN MUỐN XEM</span></h3>
                     </div>
                     <div id="halim_related_movies-2" class="owl-carousel owl-theme related-film">
                        <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $relate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="thumb grid-item post-38498">
                           <div class="halim-item">
                              <a class="halim-thumb" href="<?php echo e(route('phim',[$relate->slug])); ?>" title="<?php echo e($relate->title); ?>">
                                 <figure><img class="lazy img-responsive" src="<?php echo e(asset('public/uploads/movie/'.$relate->image)); ?>" alt="<?php echo e($relate->title); ?>" title="<?php echo e($relate->title); ?>"></figure>
                                 <?php if($relate->chanle==0): ?>
                                    <?php if($relate->hd_sd==0): ?>
                                       <span class="status">HD</span>
                                       <?php elseif($relate->hd_sd==1): ?>
                                       <span class="status">SD</span>
                                       <?php else: ?>
                                       <span class="status">Cam</span>
                                    <?php endif; ?>
                                 <?php else: ?>
                                    <span class="status">12/12</span>
                                 <?php endif; ?>

                                 <?php if($relate->phude==1): ?>
                                   <span class="episode"><i class="fa fa-play" aria-hidden="true"></i>Phụ đề</span> 
                                 <?php else: ?>
                                   <span class="episode"><i class="fa fa-play" aria-hidden="true"></i>Thuyết Minh</span> 
                                 <?php endif; ?>
                            
                                 <div class="icon_overlay"></div>
                                 <div class="halim-post-title-box">
                                    <div class="halim-post-title ">
                                       <p class="entry-title"><?php echo e($relate->title); ?></p>
                                       <p class="original_title">Monkey King: The One And Only</p>
                                    </div>
                                 </div>
                              </a>
                           </div>
                        </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </div>
                     <script>
                        jQuery(document).ready(function($) {            
                        var owl = $('#halim_related_movies-2');
                        owl.owlCarousel({loop: false,margin: 4,autoplay: true,autoplayTimeout: 3000,autoplayHoverPause: true,nav: true,navText: ['<i class="fa fa-play rotate-left"></i>', '<i class="fa fa-play rotate-right"></i>'],responsiveClass: true,responsive: {0: {items:2},480: {items:3}, 600: {items:4},1000: {items: 4}}})});
                     </script>
                  </div>
               </section>
         </main>
         <aside id="sidebar" class="col-xs-12 col-sm-12 col-md-4">
        
   
      </div>
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\webphim\resources\views/pages/watch.blade.php ENDPATH**/ ?>