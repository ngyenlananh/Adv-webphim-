

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
              <a href="<?php echo e(route('episode.index')); ?>" class="btn btn-primary">Liệt Kê Danh Sách Tập Phim</a>
                <div class="card-header">Quản Lý Tập Phim</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(!isset($episode)): ?>
                        <?php echo Form::open(['route'=>'episode.store','method'=>'POST','enctype'=>'multipart/form-data']); ?>

                    <?php else: ?>
                        <?php echo Form::open(['route'=>['episode.update',$episode->id],'method'=>'PUT','enctype'=>'multipart/form-data']); ?>

                    <?php endif; ?>
                       
                        <div class="form-group">
                            <?php echo Form::label('movie', 'Chọn Phim', []); ?>

                            <?php echo Form::select('movie_id', ['0'=>'Chọn phim' , 'Phim mới nhất'=> $list_movie], isset($episode) ? $episode->movie_id : '', ['class'=>'form-control select-movie']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('link', 'Link Phim', []); ?>

                            <?php echo Form::text('link', isset($episode) ? $episode->linkphim : '', ['class'=>'form-control','placeholder'=>'...']); ?>

                        </div>
                        <?php if(isset($episode)): ?>
                            <div class="form-group">
                                <?php echo Form::label('episode', 'Tập phim', []); ?>

                                <?php echo Form::text('episode', isset($episode) ? $episode->episode : '', ['class'=>'form-control','placeholder'=>'...', isset($episode) ? 'readonly' : '']); ?>

                            </div>
                        <?php else: ?>

                            <div class="form-group">
                                <?php echo Form::label('episode', 'Tập phim', []); ?>

                                <select name="episode" class="form-control" id="show_movie"></select>
                            </div>

                        <?php endif; ?>

                       
                        <?php if(!isset($episode)): ?>
                            <?php echo Form::submit('Thêm Tập Phim', ['class'=>'btn btn-success']); ?>

                        <?php else: ?>
                            <?php echo Form::submit('Cập Nhật Tập Phim', ['class'=>'btn btn-success']); ?>

                        <?php endif; ?>
                    <?php echo Form::close(); ?>

                </div>
            </div>
            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webphim\resources\views/admincp/episode/form.blade.php ENDPATH**/ ?>