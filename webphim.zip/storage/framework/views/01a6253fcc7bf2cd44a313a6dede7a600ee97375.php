 <aside id="sidebar" class="col-xs-12 col-sm-12 col-md-4">
               <div id="halim_tab_popular_videos-widget-7" class="widget halim_tab_popular_videos-widget">
                  <div class="section-bar clearfix">
                     <div class="section-title">
                        <span>Phim Hot</span>
                       
                     </div>
                  </div>
                  <section class="tab-content">
                     <div role="tabpanel" class="tab-pane active halim-ajax-popular-post">
                        <div class="halim-ajax-popular-post-loading hidden"></div>
                        <div id="halim-ajax-popular-post" class="popular-post">
                          <?php $__currentLoopData = $phimhot_sidebar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $hot_sidebar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="item post-37176">
                              <a href="<?php echo e(route('movie',$hot_sidebar->slug)); ?>" title="<?php echo e($hot_sidebar->title); ?>">
                                 <div class="item-link">
                                    <img src="<?php echo e(asset('uploads/movie/'.$hot_sidebar->image)); ?>" class="lazy post-thumb" alt="<?php echo e($hot_sidebar->title); ?>" title="<?php echo e($hot_sidebar->title); ?>" />
                                    <span class="is_trailer">
                                        <?php if($hot_sidebar->resolution==0): ?>
                                              HD
                                          <?php elseif($hot_sidebar->resolution==1): ?>
                                            SD
                                          <?php elseif($hot_sidebar->resolution==2): ?>
                                            HDCam
                                          <?php elseif($hot_sidebar->resolution==3): ?>
                                             Cam
                                          <?php elseif($hot_sidebar->resolution==4): ?>
                                            FullHD
                                          <?php else: ?> 
                                            Trailer

                                          <?php endif; ?>
                                    </span>
                                 </div>
                                 <p class="title"><?php echo e($hot_sidebar->title); ?></p>
                              </a>
                              <div class="viewsCount" style="color: #9d9d9d;">3.2K lượt xem</div>
                              <div style="float: left;">
                                 <span class="user-rate-image post-large-rate stars-large-vang" style="display: block;/* width: 100%; */">
                                 <span style="width: 0%"></span>
                                 </span>
                              </div>
                           </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                          
                        </div>
                     </div>
                  </section>
                  <div class="clearfix"></div>
               </div>
            </aside>

            <aside id="sidebar" class="col-xs-12 col-sm-12 col-md-4">
               <div id="halim_tab_popular_videos-widget-7" class="widget halim_tab_popular_videos-widget">
                  <div class="section-bar clearfix">
                     <div class="section-title">
                        <span>Phim Sắp Chiếu</span>
                       
                     </div>
                  </div>
                  <section class="tab-content">
                     <div role="tabpanel" class="tab-pane active halim-ajax-popular-post">
                        <div class="halim-ajax-popular-post-loading hidden"></div>
                        <div id="halim-ajax-popular-post" class="popular-post">
                          <?php $__currentLoopData = $phimhot_trailer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $hot_sidebar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="item post-37176">
                              <a href="<?php echo e(route('movie',$hot_sidebar->slug)); ?>" title="<?php echo e($hot_sidebar->title); ?>">
                                 <div class="item-link">
                                    <img src="<?php echo e(asset('uploads/movie/'.$hot_sidebar->image)); ?>" class="lazy post-thumb" alt="<?php echo e($hot_sidebar->title); ?>" title="<?php echo e($hot_sidebar->title); ?>" />
                                    <span class="is_trailer">
                                        <?php if($hot_sidebar->resolution==0): ?>
                                              HD
                                          <?php elseif($hot_sidebar->resolution==1): ?>
                                            SD
                                          <?php elseif($hot_sidebar->resolution==2): ?>
                                            HDCam
                                          <?php elseif($hot_sidebar->resolution==3): ?>
                                             Cam
                                          <?php elseif($hot_sidebar->resolution==4): ?>
                                            FullHD
                                          <?php else: ?> 
                                            Trailer

                                          <?php endif; ?>
                                    </span>
                                 </div>
                                 <p class="title"><?php echo e($hot_sidebar->title); ?></p>
                              </a>
                              <div class="viewsCount" style="color: #9d9d9d;">3.2K lượt xem</div>
                              <div style="float: left;">
                                 <span class="user-rate-image post-large-rate stars-large-vang" style="display: block;/* width: 100%; */">
                                 <span style="width: 0%"></span>
                                 </span>
                              </div>
                           </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                          
                        </div>
                     </div>
                  </section>
                  <div class="clearfix"></div>
               </div>
            </aside>

             <aside id="sidebar" class="col-xs-12 col-sm-12 col-md-4">
               <div id="halim_tab_popular_videos-widget-7" class="widget halim_tab_popular_videos-widget">
                  <div class="section-bar clearfix">
                     <div class="section-title">
                        <span>Top Views</span>
                        
                     </div>
                  </div>
                  <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item">
                          <a class="nav-link filter-sidebar" id="pills-home-tab" data-toggle="pill" href="#ngay" role="tab" aria-controls="pills-home" aria-selected="true">Ngày</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link filter-sidebar" id="pills-profile-tab" data-toggle="pill" href="#tuan" role="tab" aria-controls="pills-profile" aria-selected="false">Tuần</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link filter-sidebar" id="pills-contact-tab" data-toggle="pill" href="#thang" role="tab" aria-controls="pills-contact" aria-selected="false">Tháng</a>
                        </li>
                      </ul>

                  <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="ngay" role="tabpanel" aria-labelledby="pills-home-tab">
                       <div id="halim-ajax-popular-post" class="popular-post">

                           
                           <span id="show0"></span>
                          
                          
                          
                        </div>
                    </div>
                    <div class="tab-pane fade" id="tuan" role="tabpanel" aria-labelledby="pills-profile-tab">
                       <div id="halim-ajax-popular-post" class="popular-post">

                           <span id="show1"></span>
                          
                          
                          
                        </div>
                    </div>
                    <div class="tab-pane fade" id="thang" role="tabpanel" aria-labelledby="pills-contact-tab">
                       <div id="halim-ajax-popular-post" class="popular-post">

                           
                          <span id="show2"></span>
                          
                          
                        </div>
                    </div>
                  </div>
                 
                  <div class="clearfix"></div>
               </div>
            </aside><?php /**PATH C:\xampp\htdocs\webphim\resources\views/pages/include/sidebar.blade.php ENDPATH**/ ?>