

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
              <a href="<?php echo e(route('movie.index')); ?>" class="btn btn-primary">Liệt Kê Danh Sách Phim</a>
                <div class="card-header">Quản Lý Phim</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(!isset($movie)): ?>
                        <?php echo Form::open(['route'=>'movie.store','method'=>'POST','enctype'=>'multipart/form-data']); ?>

                    <?php else: ?>
                        <?php echo Form::open(['route'=>['movie.update',$movie->id],'method'=>'PUT','enctype'=>'multipart/form-data']); ?>

                    <?php endif; ?>
                        <div class="form-group">
                            <?php echo Form::label('title', 'Tên phim', []); ?>

                            <?php echo Form::text('title', isset($movie) ? $movie->title : '', ['class'=>'form-control','placeholder'=>'...','id'=>'slug','onkeyup'=>'ChangeToSlug()']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('tên tiếng anh', 'Tên tiếng anh', []); ?>

                            <?php echo Form::text('name_eng', isset($movie) ? $movie->name_eng : '', ['class'=>'form-control','placeholder'=>'...']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('slug', 'Đường dẫn', []); ?>

                            <?php echo Form::text('slug', isset($movie) ? $movie->slug : '', ['class'=>'form-control','placeholder'=>'...','id'=>'convert_slug']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('description', 'Mô tả phim', []); ?>

                            <?php echo Form::textarea('description', isset($movie) ? $movie->description : '', ['style'=>'resize:none', 'class'=>'form-control','placeholder'=>'...','id'=>'description']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('status', 'Trạng thái', []); ?>

                            <?php echo Form::select('status', ['1'=>'Hiển thị','0'=>'Không hiển thị'], isset($movie) ? $movie->status : '', ['class'=>'form-control']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('Category', 'Danh mục', []); ?>

                            <?php echo Form::select('category_id', $category, isset($movie) ? $movie->category_id : '', ['class'=>'form-control']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('Country', 'Quốc gia', []); ?>

                            <?php echo Form::select('country_id', $country, isset($movie) ? $movie->country_id : '', ['class'=>'form-control']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('Genre', 'Thể loại', []); ?>

                            <?php echo Form::select('genre_id', $genre, isset($movie) ? $movie->genre_id : '', ['class'=>'form-control']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('Hot', 'Phim hot', []); ?>

                            <?php echo Form::select('phim_hot', ['1'=>'Có','0'=>'Không'], isset($movie) ? $movie->phim_hot : '', ['class'=>'form-control']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('Image', 'Hình ảnh', []); ?>

                            <?php echo Form::file('image', ['class'=>'form-control-file']); ?>

                            <?php if(isset($movie)): ?>
                              <img width="150" src="<?php echo e(asset('uploads/movie/'.$movie->image)); ?>">
                            <?php endif; ?>
                        </div>
                        <?php if(!isset($movie)): ?>
                            <?php echo Form::submit('Thêm Phim', ['class'=>'btn btn-success']); ?>

                        <?php else: ?>
                            <?php echo Form::submit('Cập Nhật Phim', ['class'=>'btn btn-success']); ?>

                        <?php endif; ?>
                    <?php echo Form::close(); ?>

                </div>
            </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\webphim\resources\views/admincp/movie/form.blade.php ENDPATH**/ ?>