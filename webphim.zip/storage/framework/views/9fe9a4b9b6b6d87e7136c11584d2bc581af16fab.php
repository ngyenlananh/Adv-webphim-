
<?php $__env->startSection('content'); ?>
<div class="row container" id="wrapper">
            <div class="halim-panel-filter">
               <div class="panel-heading">
                  <div class="row">
                     <div class="col-xs-6">
                        <div class="yoast_breadcrumb hidden-xs"><span><span><a href=""><?php echo e($genre_slug->title); ?></a> » <span class="breadcrumb_last" aria-current="page">2022</span></span></span></div>
                     </div>
                  </div>
               </div>
               <div id="ajax-filter" class="panel-collapse collapse" aria-expanded="true" role="menu">
                  <div class="ajax"></div>
               </div>
            </div>
            <main id="main-contents" class="col-xs-12 col-sm-12 col-md-8">
               <section>
                  <div class="section-bar clearfix">
                     <h1 class="section-title"><span><?php echo e($genre_slug->title); ?></span></h1>
                  </div>
                  <div class="halim_box">
                     <?php $__currentLoopData = $movie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $mov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <article class="col-md-3 col-sm-3 col-xs-6 thumb grid-item post-37606">
                        <div class="halim-item">
                           <a class="halim-thumb" href="<?php echo e(route('movie',$mov->slug)); ?>">
                              <figure><img class="lazy img-responsive" src="<?php echo e(asset('uploads/movie/'.$mov->image)); ?>" alt="BẠN CÙNG PHÒNG CỦA TÔI LÀ GUMIHO" title="<?php echo e($mov->title); ?>"></figure>
                              <span class="status">
                                 
                                   <?php if($mov->resolution==0): ?>
                                              HD
                                          <?php elseif($mov->resolution==1): ?>
                                            SD
                                          <?php elseif($mov->resolution==2): ?>
                                            HDCam
                                          <?php elseif($mov->resolution==3): ?>
                                             Cam
                                          <?php elseif($mov->resolution==4): ?>
                                            FullHD
                                          <?php else: ?> 
                                            Trailer

                                          <?php endif; ?>
                              </span>
                              <span class="episode">
                                <i class="fa fa-play" aria-hidden="true"></i>
                                  <?php if($mov->phude==0): ?>
                                        Phụ đề - Tập 1/<?php echo e($mov->sotap); ?>

                                      <?php else: ?>
                                        Thuyết minh - Tập 1/<?php echo e($mov->sotap); ?>

                                      <?php endif; ?>
                              </span> 

                              <div class="icon_overlay"></div>
                              <div class="halim-post-title-box">
                                 <div class="halim-post-title ">
                                    <p class="entry-title"><?php echo e($mov->title); ?></p>
                                    <p class="original_title"><?php echo e($mov->name_eng); ?></p>
                                 </div>
                              </div>
                           </a>
                        </div>
                     </article>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                  </div>
                  <div class="clearfix"></div>
                  <div class="text-center">
                     <!-- <ul class='page-numbers'>
                        <li><span aria-current="page" class="page-numbers current">1</span></li>
                        <li><a class="page-numbers" href="">2</a></li>
                        <li><a class="page-numbers" href="">3</a></li>
                        <li><span class="page-numbers dots">&hellip;</span></li>
                        <li><a class="page-numbers" href="">55</a></li>
                        <li><a class="next page-numbers" href=""><i class="hl-down-open rotate-right"></i></a></li>
                     </ul> -->
                     <?php echo $movie->links("pagination::bootstrap-4"); ?>

                  </div>
               </section>
            </main>
            <?php echo $__env->make('pages.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webphim\resources\views/pages/genre.blade.php ENDPATH**/ ?>