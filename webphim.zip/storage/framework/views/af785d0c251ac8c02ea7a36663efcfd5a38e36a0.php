

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <a href="<?php echo e(route('movie.create')); ?>" class="btn btn-primary">Thêm Phim</a>
            <table class="table" id="tablephim">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Tên phim</th>
                  <th scope="col">Hình ảnh</th>
                  <th scope="col">Phim hot</th>
                  <!-- <th scope="col">Mô tả</th> -->
                  <th scope="col">Đường dẫn</th>
                  <th scope="col">Trạng thái</th>
                  <th scope="col">Danh mục</th>
                  <th scope="col">Thể loại</th>
                  <th scope="col">Quốc gia</th>
                  <th scope="col">Quản lý</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <th scope="row"><?php echo e($key); ?></th>
                  <td><?php echo e($cate->title); ?></td>
                  <td><img width="100" src="<?php echo e(asset('uploads/movie/'.$cate->image)); ?>"></td>
                  <td>
                    <?php if($cate->phim_hot==0): ?>
                        Không
                    <?php else: ?>
                        Có
                    <?php endif; ?>
                  </td>
                  <!-- <td><?php echo e($cate->description); ?></td> -->
                  <td><?php echo e($cate->slug); ?></td>
                  <td>
                    <?php if($cate->status): ?>
                        Hiển thị
                    <?php else: ?>
                        Không hiển thị
                    <?php endif; ?>
                  </td>
                  <td><?php echo e($cate->category->title); ?></td>
                  <td><?php echo e($cate->genre->title); ?></td>
                  <td><?php echo e($cate->country->title); ?></td>
                  <td>
                      <?php echo Form::open(['method'=>'DELETE','route'=>['movie.destroy',$cate->id],'onsubmit'=>'return confirm("Bạn có chắc muốn xóa?")']); ?>

                        <?php echo Form::submit('Xóa', ['class'=>'btn btn-danger']); ?>

                      <?php echo Form::close(); ?>

                      <a href="<?php echo e(route('movie.edit',$cate->id)); ?>" class="btn btn-warning">Sửa</a>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\webphim\resources\views/admincp/movie/index.blade.php ENDPATH**/ ?>